ELECTRICAL HUB INC. WEBSITE

The ZIP contains index.html and thank-you.html for your Netlify website.

Upload the contents of this ZIP (not the ZIP file itself if using Netlify's manual deploy page) to your Netlify site. Keep both HTML files together at the site root.

The quote form is configured for Netlify Forms. After deployment, check Netlify > Forms and submit a test request from the live website to confirm it is detected and working.

Contact details:
Phone: 647-994-4411
Email: electrical.hub2015@gmail.com
Instagram: https://www.instagram.com/electricalhubinc/
